/*
 * delay.h
 *
 *  Created on: 2019��10��15��
 *      Author: Chenhui
 */

#ifndef DELAY_H_
#define DELAY_H_

void delay(void);
void delay_us(int n);

#endif /* DELAY_H_ */
