#ifndef INFRARED_H
#define INFRARED_H

void INFRARED_Init(void);

#endif