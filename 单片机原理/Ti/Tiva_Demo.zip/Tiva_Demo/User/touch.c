/*
 * TOUCH_TSC2046.c
 *
 *  Created on: 2014��8��28��
 *      Author: Sam
 */
#include <stdbool.h>
#include <stdint.h>
#include "inc/hw_memmap.h"
#include "inc/hw_types.h"
#include "inc/hw_ints.h"
#include "driverlib/gpio.h"
#include "driverlib/pin_map.h"
#include "driverlib/ssi.h"
#include "driverlib/sysctl.h"
#include "driverlib/interrupt.h"
#include "tft.h"
#include "touch.h"
#include "utils/uartstdio.h"

extern int ui32SysClock;
uint32_t TouchXData[NUM];
uint32_t TouchYData[NUM];

//
// TSC2046 control line GPIO definitions.
//
#define TOUCH_BUSY_PERIPH           	SYSCTL_PERIPH_GPIOB
#define TOUCH_BUSY_BASE            		GPIO_PORTB_BASE
#define TOUCH_BUSY_PIN              	GPIO_PIN_1
#define TOUCH_BUSY_PIN_REG           	0x40005008
#define TOUCH_PEN_PERIPH           		SYSCTL_PERIPH_GPIOB
#define TOUCH_PEN_BASE             		GPIO_PORTB_BASE
#define TOUCH_PEN_PIN                 GPIO_PIN_0
#define TOUCH_PEN_PIN_REG           	0x40005004


#define TOUCH_XMIN  261
#define TOUCH_XMAX  3820
#define TOUCH_YMIN  200
#define TOUCH_YMAX  3820

#define TFT_XSIZE   240
#define TFT_YSIZE   400

void SSIinit(uint32_t ui32SysClockSpeed)
{
    uint32_t g_pui32DataRx[3];

    SysCtlPeripheralEnable(SYSCTL_PERIPH_SSI0);

    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);

    GPIOPinConfigure(GPIO_PA2_SSI0CLK);
    GPIOPinConfigure(GPIO_PA3_SSI0FSS);
    GPIOPinConfigure(GPIO_PA4_SSI0XDAT0);
    GPIOPinConfigure(GPIO_PA5_SSI0XDAT1);

    GPIOPinTypeSSI(GPIO_PORTA_BASE, GPIO_PIN_5 | GPIO_PIN_4 | GPIO_PIN_3 | GPIO_PIN_2);


    SSIConfigSetExpClk(SSI0_BASE, ui32SysClockSpeed, SSI_FRF_NMW, SSI_MODE_MASTER, 2000000, 12);
	

    SSIEnable(SSI0_BASE);

    while(SSIDataGetNonBlocking(SSI0_BASE, &g_pui32DataRx[0]))
    {
    }

}

void TOUCH_IQR()
{
		IntDisable(INT_GPIOB);
		GPIOIntClear(GPIO_PORTB_BASE,GPIO_INT_PIN_0);
		uint16_t ui32Loop = 0;
		uint32_t sum[2] = {0};
    SSIDataPut(SSI0_BASE, 0xd0);

		if((TouchXData[NUM-1] <= 240) && (TouchYData[NUM-1] <= 400) && !GPIOPinRead(GPIO_PORTB_BASE,GPIO_PIN_0))
		{
				TFT_DrawPoint(TouchXData[NUM-1], TouchYData[NUM-1], BLUE);
		}
		
		for(ui32Loop = 0; ui32Loop < NUM-1; ui32Loop++)
		{
				SSIDataPut(SSI0_BASE, 0x90);
				SysCtlDelay(3);
				SSIDataGet(SSI0_BASE, &TouchXData[ui32Loop]);
				SysCtlDelay(3);
				SSIDataPut(SSI0_BASE, 0xd0);
				SysCtlDelay(3);
				SSIDataGet(SSI0_BASE, &TouchYData[ui32Loop]);
				SysCtlDelay(3);
		}
		for(int i=0;i<NUM-1;i++)
		{
			sum[0] += TouchXData[i];
			sum[1] += TouchYData[i];
			
		}
		TouchXData[NUM-1] = sum[0]/(NUM-1);
		TouchYData[NUM-1] = sum[1]/(NUM-1);
		sum[0]=0;
		sum[1]=0;
		TFT_ShowData(100, 300, TouchXData[NUM-1], BLACK, WHITE);
		TFT_ShowData(100, 320, TouchYData[NUM-1], BLACK, WHITE);

		TOUCH_PointAdjust(&TouchXData[NUM-1], &TouchYData[NUM-1]);
		IntEnable(INT_GPIOB);
	
}
// As TSC2046 DIN data are latched on the rising edge of DCLK
// while DOUT are shifted on the falling edge of DCLK
// we adopt software simulation SPI to transmit data.
void TOUCH_Init()
{

    SysCtlPeripheralEnable(TOUCH_BUSY_PERIPH);
    SysCtlPeripheralEnable(TOUCH_PEN_PERIPH);
		SysCtlGPIOAHBEnable(SYSCTL_PERIPH_GPIOB);
    GPIOPinTypeGPIOInput(TOUCH_BUSY_BASE, TOUCH_BUSY_PIN);
    GPIOPinTypeGPIOInput(TOUCH_PEN_BASE, TOUCH_PEN_PIN);
		GPIOPadConfigSet(GPIO_PORTB_BASE, GPIO_PIN_0, GPIO_STRENGTH_2MA, GPIO_PIN_TYPE_STD_WPU);
//		GPIOIntRegister(GPIO_PORTB_BASE, TOUCH_IQR);
//    GPIOIntTypeSet(GPIO_PORTB_BASE, GPIO_PIN_0, GPIO_FALLING_EDGE);
//    GPIOIntEnable(GPIO_PORTB_BASE, GPIO_PIN_0);
//		IntEnable(INT_GPIOB);
//		IntMasterEnable();

    SSIinit(ui32SysClock);

}



void TOUCH_PointAdjust(uint32_t *TouchXData, uint32_t *TouchYData)
{
    uint32_t x = 0, y = 0;
    if(*TouchXData < TOUCH_XMIN || *TouchXData > TOUCH_XMAX)
    {
        *TouchXData = 0xFFFF;
        return;
    }
    if(*TouchYData < TOUCH_YMIN || *TouchYData > TOUCH_YMAX)
    {
        *TouchYData = 0xFFFF;
        return;
    }
    x = *TouchXData;
    y = *TouchYData;
    *TouchXData = TFT_XSIZE * x / (TOUCH_XMAX - TOUCH_XMIN) - 15;
    *TouchYData = TFT_YSIZE - (TFT_YSIZE * y / (TOUCH_YMAX - TOUCH_YMIN)) + 24;
}



void TOUCH_Test()
{
		
    uint16_t ui32Loop = 0;
		uint32_t sum[2] = {0};
    SSIDataPut(SSI0_BASE, 0xd0);
		while(1)
		{
		if((TouchXData[NUM-1] <= 240) && (TouchYData[NUM-1] <= 400) && !GPIOPinRead(GPIO_PORTB_BASE,GPIO_PIN_0))
		{
				TFT_DrawPoint(TouchXData[NUM-1], TouchYData[NUM-1], BLUE);
		}
		
		for(ui32Loop = 0; ui32Loop < NUM-1; ui32Loop++)
		{
				SSIDataPut(SSI0_BASE, 0x90);
				SysCtlDelay(3);
				SSIDataGet(SSI0_BASE, &TouchXData[ui32Loop]);
				SysCtlDelay(3);
				SSIDataPut(SSI0_BASE, 0xd0);
				SysCtlDelay(3);
				SSIDataGet(SSI0_BASE, &TouchYData[ui32Loop]);
				SysCtlDelay(3);
		}
		for(int i=0;i<NUM-1;i++)
		{
			sum[0] += TouchXData[i];
			sum[1] += TouchYData[i];
			
		}
		TouchXData[NUM-1] = sum[0]/(NUM-1);
		TouchYData[NUM-1] = sum[1]/(NUM-1);
		sum[0]=0;
		sum[1]=0;
		TFT_ShowData(100, 300, TouchXData[NUM-1], BLACK, WHITE);
		TFT_ShowData(100, 320, TouchYData[NUM-1], BLACK, WHITE);

		TOUCH_PointAdjust(&TouchXData[NUM-1], &TouchYData[NUM-1]);
	}
}




