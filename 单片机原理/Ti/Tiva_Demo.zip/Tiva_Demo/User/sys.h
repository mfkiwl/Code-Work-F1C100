#ifndef SYS_H
#define SYS_H

void System_Init(void);

#endif
