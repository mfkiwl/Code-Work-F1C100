#include "timer.h"

#include <stdint.h>
#include <stdbool.h>
#include "inc/hw_ints.h"
#include "inc/hw_memmap.h"
#include "inc/hw_nvic.h"
#include "inc/hw_types.h"
#include "driverlib/gpio.h"
#include "driverlib/interrupt.h"
#include "driverlib/pin_map.h"
#include "driverlib/systick.h"
#include "driverlib/sysctl.h"
#include "driverlib/timer.h"
#include "utils/uartstdio.h"
#include "adc.h"
#include "PCA9557.h"
#include "delay.h"
#include "led.h"
extern int ui32SysClock ;
int flag = 0;

void TimerIntInitial(void)
{
    SysCtlPeripheralEnable(SYSCTL_PERIPH_TIMER0);

    TimerConfigure(TIMER0_BASE, TIMER_CFG_SPLIT_PAIR  | TIMER_CFG_B_PERIODIC);

    TimerLoadSet(TIMER0_BASE, TIMER_B, 50000000/1000);

    IntRegister(INT_TIMER0B,Timer0BIntHandler);
		
    TimerIntEnable(TIMER0_BASE, TIMER_TIMB_TIMEOUT);
		IntEnable(INT_TIMER0B);
}

void Timer0BIntHandler(void)
{   //volatile uint32_t i;
    unsigned long Status;
    TimerDisable(TIMER0_BASE, TIMER_B);
    Status=TimerIntStatus(TIMER0_BASE,true);

    if(Status==TIMER_TIMB_TIMEOUT)
    {
			
			        //UARTprintf("%d\n",16000000);
        if(flag == 0)
        {
            flag = 1;
            LED_Open(1);
        }
        else
        {
            flag = 0;
            LED_Close(1);
        }
			
    }
    TimerIntClear(TIMER0_BASE, Status);
    TimerLoadSet(TIMER0_BASE, TIMER_B, 50000000/1000 );
    TimerEnable(TIMER0_BASE, TIMER_B);
}

