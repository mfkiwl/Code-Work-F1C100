/*
 * led.h
 *
 *  Created on: 2019��10��14��
 *      Author: Chenhui
 */

#ifndef LED_H_
#define LED_H_

void LED_Init(void);
void LED_Test(void);
void LED_Open(int i);
void LED_Close(int i);

#endif /* LED_H_ */
