#include "sys.h"

void System_Init()
{


}