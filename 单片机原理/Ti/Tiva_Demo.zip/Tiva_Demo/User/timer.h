#ifndef TIMER_H
#define TIMER_H

void TimerIntInitial(void);
void Timer0BIntHandler(void);

#endif
