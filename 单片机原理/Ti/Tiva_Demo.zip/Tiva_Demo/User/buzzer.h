/*
 * buzzer.h
 *
 *  Created on: 2019骞�10鏈�15鏃�
 *      Author: Chenhui
 */

#ifndef BUZZER_H_
#define BUZZER_H_

void BUZZER_Init(void);
void BUZZER_Beep(void);
void BUZZER_Open(void);
void BUZZER_Close(void);
void BUZZER_Test(void);

#endif
