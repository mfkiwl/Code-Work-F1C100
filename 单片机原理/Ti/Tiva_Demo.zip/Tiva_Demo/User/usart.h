#ifndef USART_H
#define USART_H

void USART_Init(void);

#endif

