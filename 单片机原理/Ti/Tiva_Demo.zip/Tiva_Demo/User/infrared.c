#include "infrared.h"

#include <stdint.h>
#include <stdbool.h>
#include "inc/hw_memmap.h"
#include "inc/hw_types.h"
#include "inc/hw_ints.h"
#include "driverlib/gpio.h"
#include "driverlib/pin_map.h"
#include "driverlib/rom.h"
#include "driverlib/rom_map.h"
#include "driverlib/sysctl.h"
#include "driverlib/interrupt.h"
#include "utils/uartstdio.h"

extern int ui32SysClock;
volatile uint32_t  error= 0;
volatile uint32_t  count= 0;
unsigned char  IrData[4];

/*
ch-:				0x45
ch:					0x46
ch+:				0x47
prev:				0x44
next:				0x40
play/pause:	0x43
vol-:				0x07
vol+:				0x15
eq:					0x09
0:					0x16
100+:				0x19
200+:				0x0d
1:					0x0c
2:					0x18
3:					0x5e
4:					0x08
5:					0x1c
6:					0x5a
7:					0x42
8:					0x52
9:					0x4a
*/


void IrOutput()
{
	UARTprintf("0x%x\n",IrData[2]);
//		switch(IrData[2])
//		{

//			case 12 : GPIOPinWrite(GPIO_PORTN_BASE, GPIO_PIN_1|GPIO_PIN_0 , 0x02);
//					 GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_4|GPIO_PIN_0 , 0x02);break;

//			case 24 : GPIOPinWrite(GPIO_PORTN_BASE, GPIO_PIN_1|GPIO_PIN_0 , 0x01);
//					 GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_4|GPIO_PIN_0 , 0x00);break;

//			case 94 : GPIOPinWrite(GPIO_PORTN_BASE, GPIO_PIN_1|GPIO_PIN_0 , 0x03);
//					 GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_4|GPIO_PIN_0 , 0x00);break;

//			case 8 : GPIOPinWrite(GPIO_PORTN_BASE, GPIO_PIN_1|GPIO_PIN_0 , 0x00);
//					 GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_4|GPIO_PIN_0 , 0x10);break;

//			case 28 : GPIOPinWrite(GPIO_PORTN_BASE, GPIO_PIN_1|GPIO_PIN_0 , 0x02);
//					 GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_4|GPIO_PIN_0 , 0x10);break;

//			case 90 : GPIOPinWrite(GPIO_PORTN_BASE, GPIO_PIN_1|GPIO_PIN_0 , 0x01);
//					 GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_4|GPIO_PIN_0 , 0x10);break;

//			case 66 : GPIOPinWrite(GPIO_PORTN_BASE, GPIO_PIN_1|GPIO_PIN_0 , 0x03);
//					 GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_4|GPIO_PIN_0 , 0x10);break;

//			case 82 : GPIOPinWrite(GPIO_PORTN_BASE, GPIO_PIN_1|GPIO_PIN_0 , 0x00);
//					 GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_4|GPIO_PIN_0 , 0x01);break;

//			case 74 : GPIOPinWrite(GPIO_PORTN_BASE, GPIO_PIN_1|GPIO_PIN_0 , 0x02);
//				     GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_4|GPIO_PIN_0 , 0x01);break;

//			default: GPIOPinWrite(GPIO_PORTN_BASE, GPIO_PIN_1|GPIO_PIN_0 , 0x03);
//					 GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_4|GPIO_PIN_0 , 0x11);
//		}
}

bool getdata()
{
		unsigned int i,j,IrAddressData,IrValueData;
		volatile uint32_t   temp = 0x00;
		IrAddressData = 0x00;
		IrValueData = 0x00;
		for(i=0;i<4;i++)
		{
			for(j=0;j<8;j++)
			{
				//UARTprintf("%d %x\n",j,temp);
				temp = temp>>1;
				while((GPIOPinRead(GPIO_PORTN_BASE,GPIO_PIN_4)&0x10)==0x00)
				{
				}

				SysCtlDelay(1*ui32SysClock/3000);

		    	if((GPIOPinRead(GPIO_PORTN_BASE,GPIO_PIN_4)&0x10)==0x10)
		    	{
		    		temp = temp|0x80;
		    		while((GPIOPinRead(GPIO_PORTN_BASE,GPIO_PIN_4)&0x10)==0x10)
		    		{
		    			count++;
		    			if(count>0x200000)
		    			{
								
		    				count=0;
		    				return 0;
		    			}
		    		}
		    	}
		    	else
		    	{
						
		    		temp = temp&0x7f;
		    	}

			}
			IrData[i] = temp;
			temp = 0x00;
		}
		//abc = IrData[2];
		IrAddressData = IrData[0]+IrData[1];
		IrValueData = IrData[2]+IrData[3];
		//UARTprintf("%x %x %x %x\n",IrData[0],IrData[1],IrData[2],IrData[3]);
		if((IrAddressData==0xff)&&(IrValueData==0xff))
			return 1;
		else
			
			return 0;
}

void GPION_IRQ()
{
	volatile uint32_t  LowTime,HighTime;
	unsigned long Status;
	LowTime = 0;
	HighTime = 0;
	IntDisable(INT_GPION);

	Status = GPIOIntStatus(GPIO_PORTN_BASE,true);

    if(Status==GPIO_INT_PIN_4)
    {

    	SysCtlDelay(4*ui32SysClock/3000);

    	if((GPIOPinRead(GPIO_PORTN_BASE,GPIO_PIN_4)&0x10)==0x00)
    	{
    		LowTime = 1;
    		while((GPIOPinRead(GPIO_PORTN_BASE,GPIO_PIN_4)&0x10)==0x00)
    		{

    		}
    	}
    	else
    		LowTime = 0;

    	SysCtlDelay(3*ui32SysClock/3000);
    	if((GPIOPinRead(GPIO_PORTN_BASE,GPIO_PIN_4)&0x10)==0x10)
    	{
    		HighTime = 1;
    		while((GPIOPinRead(GPIO_PORTN_BASE,GPIO_PIN_4)&0x10)==0x10)
    		{

    			if(count>0x200000)
    			{
    				count=0;
    				//return 0;
    			}
    		}
    	}
    	else
    		HighTime = 0;

    	if((HighTime==1)&&(LowTime==1))
    			{
    				if(getdata()==1)
    				{

    					IrOutput();
    				}
    				else
    				{
							

    				    	GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_1 , 0x02);
    				        SysCtlDelay(500*(ui32SysClock/3000));//2
    				       // for(i=0;i<1000;i++){;}

    				       GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_1 , 0x00);
    				        SysCtlDelay(500*(ui32SysClock/3000));//2

    				}
    			}
    	else
    	{
				
    		GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_1 , 0x02);
    		SysCtlDelay(500*(ui32SysClock/3000));
    		GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_1 , 0x00);
    		SysCtlDelay(500*(ui32SysClock/3000));
    	}

    }
    SysCtlDelay(ui32SysClock/3);
    GPIOIntClear(GPIO_PORTN_BASE,Status);
		IntEnable(INT_GPION);
}

void INFRARED_Init()
{
		SysCtlPeripheralEnable(SYSCTL_PERIPH_GPION);
    SysCtlGPIOAHBEnable(SYSCTL_PERIPH_GPION);
    GPIOPinTypeGPIOInput(GPIO_PORTN_BASE,GPIO_PIN_4 );
		GPIOIntRegister(GPIO_PORTN_BASE,GPION_IRQ);
    GPIOIntTypeSet(GPIO_PORTN_BASE,GPIO_PIN_4,GPIO_LOW_LEVEL);
    GPIOIntEnable(GPIO_PORTN_BASE,GPIO_INT_PIN_4);
}

