

///**
// * main.c
// */
#include <stdint.h>
#include <stdbool.h>
#include "inc/hw_memmap.h"
#include "inc/hw_types.h"
#include "inc/hw_ints.h"
#include "driverlib/gpio.h"
#include "driverlib/pin_map.h"
#include "driverlib/rom.h"
#include "driverlib/rom_map.h"
#include "driverlib/sysctl.h"
#include "driverlib/interrupt.h"
#include "driverlib/timer.h"
#include "utils/uartstdio.h"

#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "semphr.h"

#include "led.h"
#include "key.h"
#include "buzzer.h"
#include "pwm.h"
#include "PCA9557.h"
#include "timer.h"
#include "usart.h"
#include "adc.h"
#include "dac.h"
#include "accelerator.h"
#include "sd.h"
#include "tft.h"
#include "infrared.h"
#include "touch.h"

int ui32SysClock;


void System_Init()
{
    ui32SysClock = SysCtlClockFreqSet((SYSCTL_XTAL_25MHZ |
                                       SYSCTL_OSC_MAIN | SYSCTL_USE_PLL |
                                       SYSCTL_CFG_VCO_480), 50000000);
//		FPUEnable();
//    FPULazyStackingEnable();
    USART_Init();
    SD_Init();
    //ACCELERATOR_Init();
    TFT_Init();
    //EXADC_Init();
    //PCA9557_Init();
    //LED_Init();
    TOUCH_Init();
    //KEY_Init();
    //KEY_Int_Init();
    //TimerIntInitial();
    //BUZZER_Init();
    //PWM_Init();

    //ADC0_Init();
    //DAC_Init();
    //INFRARED_Init();
}

void NVIC_Configure()
{
    //IntPrioritySet(INT_GPION, 0x30);
    //IntPrioritySet(INT_GPIOD, 0x40);
    IntPrioritySet(INT_TIMER0B, 0xe0);

    //IntEnable(INT_GPION);
    //IntEnable(INT_GPIOD);
    IntEnable(INT_TIMER0B);
}


static void LED1Task(void *pvParameters)
{

    while(1)
    {
        LED_Open(1);
        vTaskDelay(10);
        LED_Close(1);
        vTaskDelay(10);
    }
}

static void LED2Task(void *pvParameters)
{

    while(1)
    {
        LED_Open(2);
        vTaskDelay(10);
        LED_Close(2);
        vTaskDelay(10);
    }
}


int main(void)
{
    System_Init();
	//	IntMasterEnable();
		//TFT_Test();
		//SD_Test();

//		//NVIC_Configure();

   TOUCH_Test();
    while(1)
    {


    }
    return 0;

}



