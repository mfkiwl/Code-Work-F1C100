#ifndef PWM_H
#define PWM_H

#define PWM_Frequence 10000

void PWM_Init(void);
void PWM_Test(void);


#endif
